import java.util.*;
public class PerimeterofEquilateralTriangle {
     public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter side:");
        int s=sc.nextInt();
        int ans=3*s;
        System.out.println("The perimeter of equilateral traiangles is :"+ans);
        

    }
}
