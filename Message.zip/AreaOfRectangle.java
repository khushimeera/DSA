import java.util.*;
public class AreaOfRectangle {
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter legth and width");
        int l=sc.nextInt();
        int w=sc.nextInt();
        int area=l*w;
        System.out.println("The area of Rectangle is :"+area);
    }
}
