import java.util.*;
public class Calculator {
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter two number ");
        int x=sc.nextInt();
        int y=sc.nextInt();
        System.out.println("Enter one operator to do calculation(*,+,-,/)");
        char operator=sc.next().charAt(0);
        switch(operator)
        {
            case '*':
                    int multi=x*y;
                    System.out.println("multiplacation is:"+multi);
                    break;
            case '+':
                    int add=x+y;
                    System.out.println("Addition of two number is :"+add);
                    break;

            case '-':
                    int sub=x=y;
                    System.out.println("Subtraction is:"+sub);
                    break;
            case'/':
                    if(y>0)
                    {
                        double div=x/y;
                        System.out.println("Divicion of two number is:"+div);

                    }
                    else{
                        System.out.println("number is less than zero division is not possible");
                    }
                    break;

            default:System.out.println("Invalid choice!!!!");


        }
        




    }
    
}
