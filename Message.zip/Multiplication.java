import java.util.*;
public class Multiplication {
 public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter number for multipilacation:");
    int x=sc.nextInt();
    System.out.println("Enter number till you want multiplication");
    int num=sc.nextInt();
    System.out.println("multiplacation of "+x+"is below");
    for(int i=1;i<=num;i++)
    {
        int multi=x*i;
        System.out.println(x+"*"+i+"="+multi);
    }
 }   
}
