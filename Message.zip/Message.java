import java.util.*;
public class Message {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the name to print message for that name:");
        String name=sc.nextLine();
        System.out.println("Hello "+name+"!!!!!!!!!!! how are you?");
        
    }
}
