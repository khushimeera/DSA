import java.util.*;
public class VolumeofCone {
     public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter height:");
        int h=sc.nextInt();
        System.out.println("Enter radius");
        int r=sc.nextInt();
        int ans=1/3*r*r*h;
        System.out.println("The valume of cone is :"+ans);
    }
    
    
}
