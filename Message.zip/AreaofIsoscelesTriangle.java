import java.util.*;
public class AreaofIsoscelesTriangle {
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter base and side :");
        int b=sc.nextInt();
        int s=sc.nextInt();
        double area=0.5f*b*Math.sqrt(s*s-(b/2)*(b/2));
        System.out.println("The Area of Isosceles Triangle:"+area);
    }
}
