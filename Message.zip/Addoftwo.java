import java.util.*;
public class Addoftwo {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter first number");
        int x=sc.nextInt();
        System.out.println("Enter second number");
        int y=sc.nextInt();
        int add=x+y;
        System.out.println("Addition of two number is :"+add);

    }
    
}
