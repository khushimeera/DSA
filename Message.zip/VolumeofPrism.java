import java.util.*;
public class VolumeofPrism {
         public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter height:");
        int h=sc.nextInt();
        System.out.println("Enter base");
        int b=sc.nextInt();
        int ans=b*h;
        System.out.println("the valume of prism is :"+ans);
        

    }
    
}
