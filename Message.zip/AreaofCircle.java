import java.util.*;
public class AreaofCircle {
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter radius:");
        int r=sc.nextInt();
        double pi=3.147;
        double area=pi*r*r;
        System.out.println("The area of circle is :"+area);
    }
}
