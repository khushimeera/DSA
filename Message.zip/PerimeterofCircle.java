import java.util.*;
public class PerimeterofCircle {
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter radius:");
        int r=sc.nextInt();
        double pi=3.147;
        double ans=2*pi*r;
        System.out.println("Perimeter of Circle is  "+ans);
    }
}
