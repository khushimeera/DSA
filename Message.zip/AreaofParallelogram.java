import java.util.*;
public class AreaofParallelogram{
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the base and height");
        int b=sc.nextInt();
        int h=sc.nextInt();
        int ans=b*h;
        System.out.println("The Area of Parallelogram"+ans);
    }
    
}
