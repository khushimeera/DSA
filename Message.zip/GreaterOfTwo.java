import java.util.*;
public class GreaterOfTwo {
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter two number");
        int x=sc.nextInt();
        int y=sc.nextInt();
        if(x>y)
        {
            System.out.println(x+"is the greater number");
        } 
        else{
            System.out.println(y+"is the greater number");
        }
    }
    
}