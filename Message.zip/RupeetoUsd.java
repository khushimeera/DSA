import java.util.*;
public class RupeetoUsd {
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter indian rupee");
        double inrAmount=sc.nextDouble();
        double ExchangeRate=0.014;
        double usdAmount=inrAmount*ExchangeRate;
        System.out.println(inrAmount+" is equal to "+usdAmount+"USD");
    }
    
}
