import java.util.*;
public class PerimeterOfSquare {
     public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter side:");
        int s=sc.nextInt();
        
        int ans=4*(s);
        System.out.println("The perimeter of square is :"+ans);
    }
    
    
}
