import java.util.*;
public class Stringpalindrome {
    public static void main(String []args)
    {
        
    }
    
}
