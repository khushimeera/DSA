import java.util.*;
public class AreaofEquilateralTriangle {
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter  side :");
        int s=sc.nextInt();
       double ans=Math.sqrt(3)/4*s*s;
       System.out.println("The  Area of Equilateral Triangle is : "+ans);
    }
    
}
