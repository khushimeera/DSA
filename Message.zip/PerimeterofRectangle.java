import java.util.*;
public class PerimeterofRectangle {
     public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter length:");
        int l=sc.nextInt();
        System.out.println("Enter width");
        int w=sc.nextInt();
        int ans=3*(l+w);
        System.out.println("The perimeter of parallelogram is :"+ans);
    }
    
    
}
