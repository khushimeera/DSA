import java.util.*;
public class LcmExample {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter two number to find lcm:");
        int a=sc.nextInt();
        int b=sc.nextInt();
        int gcd=1;
        for(int i=1;i<=a&&i<=b;++i)
        {
            if((a%i==0)&&(b%i==0))
            {
                gcd=i;
            }

        }
        int lcm=a*b/gcd;
        System.out.println("The lcm of "+a+" and "+b+" is:"+lcm);

    }
    
}
