import java.util.*;
public class AreaofRhombus{
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter daigonal:");
        int d1=sc.nextInt();
        int d2=sc.nextInt();
        double ans=0.5*d1*d2;
        System.out.println("The Area of Rhombus:"+ans);
    }
    
}
