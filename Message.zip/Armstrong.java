import java.util.*;
public class Armstrong {
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter number");
        int n=sc.nextInt();
        int temp=n;
        int rem,sum=0;
        while(n>0)
        {
            rem=n%10;
            sum=sum+(rem*rem*rem);
            n=n/10;
        }
        if(temp==sum)
        {
            System.out.println("Armstrong number");
        }
        else
        {
            System.out.println("Not armstrong number");
        }
    }

    
}
